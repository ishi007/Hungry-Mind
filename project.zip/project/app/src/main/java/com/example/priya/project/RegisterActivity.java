package com.example.priya.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;

public class RegisterActivity extends AppCompatActivity {
    EditText name,password,phone;
    Button submit;
    DynamoDBMapper dynamoDBMapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        AWSMobileClient.getInstance().initialize(this, new AWSStartupHandler() {

            @Override
            public void onComplete(AWSStartupResult awsStartupResult) {

                // Add code to instantiate a AmazonDynamoDBClient
                AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(AWSMobileClient.getInstance().getCredentialsProvider());
                dynamoDBMapper = DynamoDBMapper.builder()
                        .dynamoDBClient(dynamoDBClient)
                        .awsConfiguration(
                                AWSMobileClient.getInstance().getConfiguration())
                        .build();

            }
        }).execute();
        name=findViewById(R.id.name);
        password=findViewById(R.id.pass1);
        phone=findViewById(R.id.phone1);
        submit=findViewById(R.id.submit);

        final cust customer = new cust();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

   //     customer.setCust_name(name.getText().toString());
     //   customer.setCust_pass(password.getText().toString());
     //   customer.setCust_phone(Integer.parseInt(phone.getText().toString()));
      //  customer.setRating(0);

       // new Thread(new Runnable() {
         //   @Override
           // public void run() {
             //   dynamoDBMapper.save(customer);
                // Item saved
         //   }
       // }).start();
        Intent intent=new Intent(RegisterActivity.this,Setup2Activity.class);
        startActivity(intent);
            }
        });

    }
}
