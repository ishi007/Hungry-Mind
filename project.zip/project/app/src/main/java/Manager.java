import android.content.Context;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.regions.Regions;


public class Manager  {
    public CognitoCachingCredentialsProvider getCredential(Context context){
        // Initialize the Amazon Cognito credentials provider
        CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                context,
                "us-east-2:e770d713-8ae6-42a4-bdf7-d90befb2ea4b", // Identity pool ID
                Regions.US_EAST_2 // Region
        );

        return credentialsProvider;
    }
}
